
Rabia Dental Clinic - Photo-Rich Elegant Flask Site

How to run locally (Amazon Linux / Ubuntu):
1. python3 -m venv venv
2. source venv/bin/activate
3. pip install -r requirements.txt
4. python app.py
5. Open http://localhost:5000

Notes:
- This site is a demo. Forms POST to /contact and /book and are printed to console.
- Static assets are in static/images and static/css/style.css
