from flask import Flask, render_template, request, redirect, url_for
app = Flask(__name__, static_folder='static', template_folder='templates')

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/services')
def services():
    return render_template('services.html')

@app.route('/doctors')
def doctors():
    return render_template('doctors.html')

@app.route('/gallery')
def gallery():
    return render_template('gallery.html')

@app.route('/contact', methods=['GET','POST'])
def contact():
    if request.method=='POST':
        # In production, save to DB or send email
        print('Contact form:', request.form)
        return redirect(url_for('contact'))
    return render_template('contact.html')

@app.route('/book', methods=['POST'])
def book():
    print('Appointment:', request.form)
    return redirect(url_for('home'))

if __name__=='__main__':
    app.run(host='0.0.0.0', port=5000)
